java -jar shabbat_bot.jar
